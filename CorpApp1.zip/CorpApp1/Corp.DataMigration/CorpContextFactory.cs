﻿/* ---------------------------------------------------
 * Миграции БД corpdb, схема ent, контекст CorpContext
 * ---------------------------------------------------
 * Package Manager Console:
 *
 * Создать новую миграцию по измененному контексту:
 *   PM> EntityFrameworkCore\Add-Migration "НазваниеМиграции" -OutputDir History -Project Corp.DataMigration -StartupProject Corp.DataMigration
 *
 * Сгенерировать sql-скрипт для БД:
 *   PM> EntityFrameworkCore\Script-Migration -From "НазваниеПредМиграции" -Project Corp.DataMigration -StartupProject Corp.DataMigration
 *
 * Применить изменения в БД:
 *   PM> EntityFrameworkCore\Update-Database -Project Corp.DataMigration -StartupProject Corp.DataMigration
 */

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

using Corp.Entities;


namespace Corp.DataMigration
{
    internal class CorpContextFactory : IDesignTimeDbContextFactory<CorpContext>
    {
        static CorpContextFactory() =>
            AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);

        public CorpContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<CorpContext>();

            const string connectionString =
                "Host=localhost;Port=5433;Database=corpdb;Persist Security Info=True;User ID=postgres;Password=postgres";

            optionsBuilder
                .UseNpgsql(
                    connectionString,
                    options => options
                        .CommandTimeout(1000)
                        .MigrationsAssembly("Corp.DataMigration")
                        .MigrationsHistoryTable("EntMigrations", "public"));

            return new CorpContext(optionsBuilder.Options);
        }
    }
}
﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Corp.DataMigration.History
{
    /// <inheritdoc />
    public partial class CreateUserUnique : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_UserInRoles_UserId",
                schema: "ent",
                table: "UserInRoles");

            migrationBuilder.CreateIndex(
                name: "IX_Users_Name",
                schema: "ent",
                table: "Users",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_UserInRoles_UserId_RoleId",
                schema: "ent",
                table: "UserInRoles",
                columns: new[] { "UserId", "RoleId" },
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Users_Name",
                schema: "ent",
                table: "Users");

            migrationBuilder.DropIndex(
                name: "IX_UserInRoles_UserId_RoleId",
                schema: "ent",
                table: "UserInRoles");

            migrationBuilder.CreateIndex(
                name: "IX_UserInRoles_UserId",
                schema: "ent",
                table: "UserInRoles",
                column: "UserId");
        }
    }
}

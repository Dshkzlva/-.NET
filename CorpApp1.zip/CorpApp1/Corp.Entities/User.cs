﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Corp.Entities
{
    /// <summary>
    /// Пользователь
    /// </summary>
    public class User
    {
        public Guid Id { get; set; }

        /// <summary>
        /// Логин
        /// </summary>
        [MaxLength(32)]
        public required string Name { get; set; }

        /// <summary>
        /// Имя
        /// </summary>
        [MaxLength(64)]
        public string? FirstName { get; set; }

        /// <summary>
        /// Отчество
        /// </summary>
        [MaxLength(64)]
        public string? MiddleName { get; set; }

        /// <summary>
        /// Фамилия
        /// </summary>
        [MaxLength(64)]
        public string? LastName { get; set; }

        /// <summary>
        /// Дата/время последнего входа
        /// </summary>
        public DateTime? LastActivityDate { get; set; }

        [InverseProperty(nameof(UserPassword.User))]
        public virtual UserPassword? Password { get; set; }

        [InverseProperty(nameof(UserInRole.User))]
        public virtual ICollection<UserInRole>? Roles { get; set; }
    }
}
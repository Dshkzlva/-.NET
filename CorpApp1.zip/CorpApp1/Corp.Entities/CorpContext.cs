﻿using System.Diagnostics;

using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;


namespace Corp.Entities
{
    public class CorpContext(DbContextOptions options) : DbContext(options)
    {
        #region Config

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseLazyLoadingProxies()
                          .LogTo(message => Debug.WriteLine(message), LogLevel.Information)
                          .EnableSensitiveDataLogging();
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.HasDefaultSchema("ent");

            builder.Entity<User>()
                   .HasIndex(e => e.Name)
                   .IsUnique();

            builder.Entity<UserInRole>()
                   .HasIndex(e => new { e.UserId, e.RoleId })
                   .IsUnique();
        }

        protected override void ConfigureConventions(ModelConfigurationBuilder builder)
        {
            builder.Conventions.Remove(typeof(
                Microsoft.EntityFrameworkCore.Metadata.Conventions.CascadeDeleteConvention));

            base.ConfigureConventions(builder);
        }

        #endregion Config

        public DbSet<User> Users { get; set; }
        public DbSet<UserPassword> UserPasswords { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<UserInRole> UserInRoles { get; set; }
    }
}
﻿using System.ComponentModel.DataAnnotations;

namespace Corp.Entities
{
    /// <summary>
    /// Роль
    /// </summary>
    public class Role
    {
        public Guid Id { get; set; }

        /// <summary>
        /// Имя роли
        /// </summary>
        [MaxLength(16)]
        public required string Name { get; set; }
    }
}
﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;

namespace Corp.Entities
{
    /// <summary>
    /// Роли пользователей
    /// </summary>
    public class UserInRole
    {
        public Guid Id { get; set; }

        /// <summary>
        /// Пользователь
        /// </summary>
        public Guid UserId { get; set; }

        [ForeignKey(nameof(UserId))]
        [DeleteBehavior(DeleteBehavior.Cascade)]
        public virtual User? User { get; set; }

        /// <summary>
        /// Роль
        /// </summary>
        public Guid RoleId { get; set; }

        [ForeignKey(nameof(RoleId))]
        public virtual Role? Role { get; set; }

        /// <summary>
        /// Дата добавления
        /// </summary>
        public DateTime CreateDate { get; set; }
    }
}
﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Corp.Entities
{
    /// <summary>
    /// Пароль
    /// </summary>
    public class UserPassword
    {
        public Guid Id { get; set; }

        /// <summary>
        /// Пользователь
        /// </summary>
        public Guid UserId { get; set; }

        [ForeignKey(nameof(UserId))]
        [DeleteBehavior(DeleteBehavior.Cascade)]
        public virtual User? User { get; set; }

        /// <summary>
        /// Hash пароля SHA-512
        /// </summary>
        [MaxLength(128)]
        public required string Password { get; set; }
    }
}
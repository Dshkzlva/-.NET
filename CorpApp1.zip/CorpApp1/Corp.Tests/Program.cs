﻿using System.Security.Cryptography;
using System.Text;

using Microsoft.EntityFrameworkCore;

using Corp.Entities;


AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);

const string connectionString =
    "Host=localhost;Port=5433;Database=corpdb;Persist Security Info=True;"
    + "User ID=postgres;Password=postgres";

var optionsBuilder = new DbContextOptionsBuilder<CorpContext>();

using CorpContext db = new(
    optionsBuilder.UseNpgsql(connectionString).Options);

// db.Database.EnsureDeleted(); // Пересоздать БД
// db.Database.EnsureCreated();

Guid roleId = Guid.NewGuid();
Guid[] userIds = [Guid.NewGuid(), Guid.NewGuid()];

db.Users.RemoveRange(db.Users.ToList());
db.SaveChanges();

db.Roles.RemoveRange(db.Roles.ToList());
db.SaveChanges();

db.Users.Add(new User
{
    Id = userIds[0],
    Name = "user1"
});

db.Users.Add(new User
{
    Id = userIds[1],
    Name = "user2"
});

db.Roles.Add(new Role
{
    Id = roleId,
    Name = "Admin"
});

byte[] pswd = Encoding.UTF8.GetBytes("1234");
byte[] hash = SHA512.HashData(pswd);
string hex = BitConverter.ToString(hash).Replace("-", "");

db.UserPasswords.Add(new UserPassword
{
    Id = Guid.NewGuid(),
    Password = hex,
    UserId = userIds[0]
});

db.UserInRoles.Add(new UserInRole
{
    Id = Guid.NewGuid(),
    UserId = userIds[0],
    RoleId = roleId,
    CreateDate = DateTime.Now
});

db.SaveChanges();

var users = db.Users.ToList();

var admins = (from u in db.Users
              from uir in db.UserInRoles

              let r = uir.Role

              where u.Id == uir.UserId
                    && r.Name == "Admin"

              select u).ToList();

Console.WriteLine(admins[0].Name);
Console.WriteLine("Ok");